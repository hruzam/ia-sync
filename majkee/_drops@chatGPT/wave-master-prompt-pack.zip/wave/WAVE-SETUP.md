# Wave Setup

## 1. ChatGPT Project

Create a new ChatGPT Project named **wave**.

Recommended memory mode: **Project-only**. This keeps Wave’s project context isolated from unrelated chats and memories.

Paste the contents of `WAVE.md` into **Project settings → Project instructions**.

Use **Candid** personality for direct but constructive conversation. The current global personality can remain unchanged if you want Wave’s style to exist only inside this project.

### Recommended ChatGPT model / effort

- Routine dialogue and small technical questions: **Medium**
- Architecture, debugging, code review, and multi-step reasoning: **High**
- Difficult cross-system decisions or deep audits: **Extra High**
- Rare, high-value final synthesis or independent second opinion: **Pro**

A sensible default for the Wave project is **High**. Drop to Medium for rapid interactive work; raise effort only when the problem justifies it.

## 2. Codex CLI

Place:

- `AGENTS.md` at the repository root
- `WAVE.md` at the repository root if you want Codex to read the full shared philosophy
- `codex-config.toml` at `~/.codex/config.toml` after reviewing and merging it with your existing config

The baseline uses:

- `gpt-5.6-sol`
- medium execution reasoning
- high planning reasoning
- pragmatic personality
- workspace-write sandbox
- on-request approval
- no subprocess network access by default

Use `/model` in Codex for one-session changes.

Suggested operating choices:

- ordinary implementation: Sol / medium
- architecture or difficult debugging: Sol / high
- security audit or exceptionally hard task: Sol / xhigh
- narrow repetitive transformations: Terra or Luna, where available

## 3. Claude Code Cohabitation

Keep Claude-specific identity in `CLAUDE.md` or Nabla’s existing file.

Do not make `CLAUDE.md` and `AGENTS.md` competing sources of project facts. Put shared state into neutral files:

- `PROJECT_STATE.md`
- `DECISIONS.md`
- `ARCHITECTURE.md`
- `AI_HANDOFF.md`

A clean division is:

- `WAVE.md`: ChatGPT/Wave philosophy
- `AGENTS.md`: Codex execution rules
- `CLAUDE.md`: Claude/Nabla instructions
- neutral project files: shared truth

Before either agent starts, it should inspect Git state and the latest handoff. After substantial work, it should update `AI_HANDOFF.md`.
